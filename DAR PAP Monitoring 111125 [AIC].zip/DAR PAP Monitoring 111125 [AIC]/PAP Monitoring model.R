#PAP Monitoring model
#Install packages

#.libPaths("C:/Users/er22346/Documents/DAR PAP Monitoring/PAP Monitoring")
#install.packages("readxl")
#install.packages('ggplot2')
#install.packages('dplyr')
#install.packages('rje')

#Load packages
#library(readxl)
#library(ggplot2)
#library(dplyr)
library(rje)

#Set seed
set.seed(29949510)  #Seed was randomly generated 

#Load file
scenario_file_used<-0
deterministic_file_used<-1 #Note if running the deterministic analysis, for quicker analysis, lower the number of iterations to 1

# Define global parameters for the data and source code directories
data_directory <- "data"
code_directory <- "code"
scenario_results_directory<-"scenario_results"
DSA_results_directory<-"DSA_results"

#Load functions
source(paste0(code_directory, "/PAP Monitoring inputs.R"))
source(paste0(code_directory, "/PAP Monitoring transition matrix.R"))
source(paste0(code_directory, "/PAP Monitoring mortality.R"))
source(paste0(code_directory, "/PAP Monitoring costs.R"))
source(paste0(code_directory, "/PAP Monitoring intense monitoring costs.R"))
source(paste0(code_directory, "/PAP Monitoring trial utilities.R"))
source(paste0(code_directory, "/PAP Monitoring calculations.R"))

# Define global parameters that are accessed by all functions
deterministic_analysis<-1
n_iterations<-1
n_states<-9
n_monitoring_strategies<-3
n_cycles<-396
HTW_model<-0
half_cycle_correction<-1
trial_utilities_switch<-1
adherence_drop_off<-0
adherence_rate<-0.90
scenario_6c<-1 #Must also turn on trial_utilities_switch
threshold_analysis_switch<-0
hosp_based_monitoring<-0

#Cycle length in yrs
cycle_length<-1/12
#Per cycle discount rate
Discount_rate<-0.035

#Cohort demographics
##Age
initial_age<-69
##Sex
prop_f<-0.30

#CEP printed
CEP<-"CardioMEMS"

#Health states
state_names<-c("Stable_HF",
               "1st_Hospitalisation",
               "Stable_HF2",
               "2nd_Hospitalisation",
               "Stable_HF3",
               "Subsequent_hospitalisation",
               "Stable_HF4",
               "End_of_life",
               "Death")

#Monitoring strategies
monitoring_names<-c("CardioMEMS",
                    "Cordella",
                    "No_monitoring")

#Mortality age groups
mortality_groups<-c("45_50",
                    "50_55",
                    "55_60",
                    "60_65",
                    "65_70",
                    "70_75",
                    "75_80",
                    "80_85",
                    "85_90",
                    "90")

#Generate a matrix of input parameters
input_parameters <- generate_input_parameters(n_iterations)

# Generate the net benefit using the above input parameters
model_output <- generate_ICER(input_parameters)

# Average costs
rowMeans(model_output$total_costs)
# Average QALYS
rowMeans(model_output$total_QALYs)
# Average LYs
rowMeans(model_output$total_LYs)

# Calculate an ICER without BCEA
incremental_costs <- t(model_output$total_costs) - t(model_output$total_costs)[, "No_monitoring"]
incremental_QALYs <- t(model_output$total_QALYs) - t(model_output$total_QALYs)[, "No_monitoring"]
#ICER <- colMeans(incremental_costs) / colMeans(incremental_QALYs)
ICER <- colMeans(incremental_costs) / colMeans(incremental_QALYs)
#Report results
ICER

IC<-colMeans(incremental_costs)
IQ<-colMeans(incremental_QALYs)

##CEP

library(ggplot2)

results_df_for_plot <- as.data.frame(cbind(incremental_costs, incremental_QALYs))
colnames(results_df_for_plot) <-
  c(paste0(colnames(incremental_costs), "_inc_costs"),
    paste0(colnames(incremental_QALYs), "_inc_QALYs"))

CEP_CardioMEMS <- ggplot(data = results_df_for_plot) + theme_bw() + 
  geom_point(aes(x = CardioMEMS_inc_QALYs, y = CardioMEMS_inc_costs), size = 0.1, color ="black") +
  geom_hline(aes(yintercept = 0)) + geom_vline(aes(xintercept = 0)) +
  ylab("Incremental Costs (£)") + xlab("Incremental QALYs") +
  geom_abline(slope=20000,intercept=0,linetype="dashed", color ="dodgerblue2", linewidth = 1.25) +
  geom_abline(slope=30000,intercept=0,linetype="dotted", color ="dodgerblue3", linewidth = 1.25) +
  ggtitle("CE plane for CardioMEMS") +   theme(
    plot.title = element_text(hjust = 0.5, size = 20),  # Change title size
    axis.title.x = element_text(size = 20),           # Change x-axis label size
    axis.title.y = element_text(size = 20),             # Change y-axis label size
    axis.text.x = element_text(size = 14),  # Change x-axis tick label size
    axis.text.y = element_text(size = 14)   # Change y-axis tick label size
  )
CEP_CardioMEMS

CEP_Cordella <-ggplot(data = results_df_for_plot) + theme_bw() + 
  geom_point(aes(x = Cordella_inc_QALYs, y = Cordella_inc_costs), size = 0.1) +
  geom_hline(aes(yintercept = 0)) + geom_vline(aes(xintercept = 0)) +
  ylab("Incremental Costs (£)") + xlab("Incremental QALYs") +
  geom_abline(slope=20000,intercept=0,linetype="dashed") +
  geom_abline(slope=30000,intercept=0,linetype="dotted") +
  ggtitle("CE plane for Cordella") + theme(plot.title = element_text(hjust = 0.5))
CEP_Cordella

## CEAC
ceac_monitoring_names<-c("CardioMEMS", "Cordella", "Standard care")

ceac_function <- function(wtp) {
  nb <- t(model_output$total_QALYs) * wtp - t(model_output$total_costs)
  prob_ce <- c(sum(max.col(nb) == 1) / n_iterations,
               sum(max.col(nb) == 2) / n_iterations,
               sum(max.col(nb) == 3) / n_iterations)
  names(prob_ce) <- ceac_monitoring_names
  return(prob_ce)
}

wtp_values <- seq(0, 50000, by = 500)
prob_ce_values <- matrix(0, nrow = length(wtp_values), ncol = length(ceac_monitoring_names))
colnames(prob_ce_values) <- ceac_monitoring_names

for (i in 1:length(wtp_values)) {
  prob_ce_values[i,] <- ceac_function(wtp_values[i])
}

library(tidyr)
ceac_df_wide <- as.data.frame(cbind(wtp_values, prob_ce_values))
ceac_df <- pivot_longer(ceac_df_wide,
                        cols = ceac_monitoring_names,
                        values_to = "prob_ce", names_to = "monitoring_strategy")

ggplot(data = ceac_df) + theme_bw() + 
  geom_line(aes(x = wtp_values, y = prob_ce, col = monitoring_strategy)) +
  xlab("WTP (£)") + ylab("p(CE)") +
  scale_x_continuous(limits = c(0, 50000), expand = expansion(add = c(0,2000))) +
  scale_y_continuous(limits = c(0, 1), expand = expansion(add = c(0,0)))

#Pairwise CEACs

ceac_function_pairs <- function(wtp) {
  nb <- t(model_output$total_QALYs) * wtp - t(model_output$total_costs)
  prob_ce_CardioMEMS_vs_No_monitoring <-
    sum(nb[,"CardioMEMS"] > nb[,"No_monitoring"]) / n_iterations
  prob_ce_Cordella_vs_No_monitoring <-
    sum(nb[,"Cordella"] > nb[,"No_monitoring"]) / n_iterations
  prob_ce_Cordella_vs_CardioMEMS <-
    sum(nb[,"Cordella"] > nb[,"CardioMEMS"]) / n_iterations
  prob_ce_pairs <- c(prob_ce_CardioMEMS_vs_No_monitoring,
                     prob_ce_Cordella_vs_No_monitoring,
                     prob_ce_Cordella_vs_CardioMEMS)
  names(prob_ce_pairs) <- c("prob_ce_CardioMEMS_vs_No_monitoring",
                            "prob_ce_Cordella_vs_No_monitoring",
                            "prob_ce_Cordella_vs_CardioMEMS")
  return(prob_ce_pairs)
}

wtp_values <- seq(0, 50000, by = 500)
prob_ce_pairs_values <- matrix(0, nrow = length(wtp_values), ncol = length(monitoring_names))
colnames(prob_ce_pairs_values) <- c("prob_ce_CardioMEMS_vs_No_monitoring",
                                    "prob_ce_Cordella_vs_No_monitoring",
                                    "prob_ce_Cordella_vs_CardioMEMS")

for (i in 1:length(wtp_values)) {
  prob_ce_pairs_values[i,] <- ceac_function_pairs(wtp_values[i])
}

ceac_df_pairs <- as.data.frame(cbind(wtp_values, prob_ce_pairs_values))

ggplot(data = ceac_df_pairs) + theme_bw() + 
  geom_line(aes(x = wtp_values, y = prob_ce_CardioMEMS_vs_No_monitoring)) +
  xlab("WTP (?)") + ylab("p(CE)") +
  scale_x_continuous(limits = c(0, 50000), expand = expansion(add = c(0,2000))) +
  scale_y_continuous(limits = c(0, 1), expand = expansion(add = c(0,0))) +
  ggtitle("CardioMEMS vs Standard care") + theme(plot.title = element_text(hjust = 0.5))

ggplot(data = ceac_df_pairs) + theme_bw() + 
  geom_line(aes(x = wtp_values, y = prob_ce_Cordella_vs_No_monitoring)) +
  xlab("WTP (?)") + ylab("p(CE)") +
  scale_x_continuous(limits = c(0, 50000), expand = expansion(add = c(0,2000))) +
  scale_y_continuous(limits = c(0, 1), expand = expansion(add = c(0,0))) +
  ggtitle("Cordella vs Standard care") + theme(plot.title = element_text(hjust = 0.5))

ggplot(data = ceac_df_pairs) + theme_bw() + 
  geom_line(aes(x = wtp_values, y = prob_ce_Cordella_vs_CardioMEMS)) +
  xlab("WTP (?)") + ylab("p(CE)") +
  scale_x_continuous(limits = c(0, 50000), expand = expansion(add = c(0,2000))) +
  scale_y_continuous(limits = c(0, 1), expand = expansion(add = c(0,0))) +
  ggtitle("Cordella vs Standard care") + theme(plot.title = element_text(hjust = 0.5))
