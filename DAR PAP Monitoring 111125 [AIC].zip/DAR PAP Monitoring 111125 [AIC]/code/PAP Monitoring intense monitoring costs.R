#PAP Monitoring high intensity monitoring costs


generate_intense_monitoring_costs <- function(input_parameters) {
  
  intense_monitoring_costs <- array(NA, dim = c(n_cycles, n_monitoring_strategies, n_iterations, n_states),
                       dimnames = list(NULL,monitoring_names, NULL, state_names))
  
  #High intensity monitoring costs for the early period
  intense_monitoring_costs[1:3,"CardioMEMS",,1:8]<-input_parameters$costs_intense_monitoring_CM
  intense_monitoring_costs[1:3,"Cordella",,1:8]<-input_parameters$costs_implantation_Cordella
  
  #After the first three cycles
  intense_monitoring_costs[4:n_cycles,1:2,,1:8]<-0
  
  #Non monitoring arm
  intense_monitoring_costs[,3,,]<-0
  
  #Death state
  intense_monitoring_costs[,,,"Death"]<-0
  
  return(intense_monitoring_costs)
  print(intense_monitoring_costs)
}
  