#Results calculations

generate_ICER <- function(input_parameters) {
  #Create arrays to store results
  transition_matrices <- generate_transition_matrices(input_parameters)
  state_costs <- generate_state_costs(input_parameters)
  state_QALYs <- input_parameters[, grepl("utilities_", colnames(input_parameters))]*cycle_length
  trial_utilities <-generate_trial_utilities(input_parameters) *cycle_length
  intense_monitoring_costs<-generate_intense_monitoring_costs(input_parameters)

  #Monitoring costs
  if(HTW_model==1){
    monitoring_costs <- t(input_parameters[, grepl("monitoring_costs_", colnames(input_parameters))])
  }else{
    monitoring_costs <- array(NA, dim = c(n_monitoring_strategies, n_iterations),
                                               dimnames = list(monitoring_names, NULL))
  
    Cost_CardioMEMS <- input_parameters$costs_device_CM + 
      input_parameters$costs_implantation_CM +
      input_parameters$device_complication_CM*input_parameters$costs_device_failure_CM+
      input_parameters$implant_failure_CM*input_parameters$costs_implant_failure_CM
    Cost_Cordella <- input_parameters$costs_device_Cordella + 
      input_parameters$costs_implantation_Cordella +
      input_parameters$device_complication_Cordella*input_parameters$costs_device_failure_Cordella+
      input_parameters$implant_failure_Cordella*input_parameters$costs_implant_failure_Cordella
    
    
    monitoring_costs["CardioMEMS",]<- Cost_CardioMEMS
    monitoring_costs["Cordella",]<- Cost_Cordella
    monitoring_costs["No_monitoring",]<- 0
    
  }#Ends monitoring costs if
  

  #Half cycle correction
  HCC_cohort_vectors<-array(0, dim = c(n_cycles, n_monitoring_strategies, n_iterations, n_states),
                                 dimnames = list(NULL,monitoring_names,NULL,state_names))
  
  #Arrays for the cohort vectors at each cycle
  cohort_vectors <- array(dim = c(n_cycles, n_monitoring_strategies, n_iterations,  n_states), 
                  dimnames = list(NULL, monitoring_names, NULL, state_names))
  cohort_TOTAL <- array(dim = c(n_cycles, n_monitoring_strategies, n_iterations), 
                          dimnames = list(NULL, monitoring_names, NULL))
  # Everyone starts in Stable HF
  cohort_vectors[1, , , "Stable_HF"] <- 1 
  # All other proportions start at zero
  cohort_vectors[1, , , -1] <- 0
  
  #Arrays with the costs and QALYs per cycle
  cycle_costs <- array(dim = c(n_cycles, n_monitoring_strategies, n_iterations), 
                       dimnames = list(NULL, monitoring_names, NULL))
  cycle_state_QALYs<-array(dim = c(n_cycles, n_monitoring_strategies, n_iterations,n_states), 
                           dimnames = list(NULL, monitoring_names, NULL))
  cycle_QALYs <- array(dim = c(n_cycles, n_monitoring_strategies, n_iterations), 
                       dimnames = list(NULL, monitoring_names, NULL))
  cycle_LYs <- array(dim = c(n_cycles, n_monitoring_strategies, n_iterations), 
                     dimnames = list(NULL, monitoring_names, NULL))
  
  #Arrays with total costs and QALYs for each PSA iteration
  total_costs <- array(dim = c(n_monitoring_strategies, n_iterations), 
                       dimnames = list(monitoring_names, NULL))
  total_QALYs <- array(dim = c(n_monitoring_strategies, n_iterations), 
                       dimnames = list(monitoring_names, NULL))
  total_LYs <- array(dim = c(n_monitoring_strategies, n_iterations), 
                    dimnames = list(monitoring_names, NULL))
  
  #Set up discount factor
  discount_factor<-array(n_cycles)
  yrs<-array(n_cycles)
  for (i_cycle in 1:n_cycles) {
       yrs[i_cycle]<-(i_cycle-1)/12
    yrs<-trunc(yrs)
    discount_factor[i_cycle]<-1/((1+Discount_rate)^yrs[i_cycle])
  }
  
  #Model main loops
  #Loop over all monitoring strategies
  for (i_monitoring in 1:n_monitoring_strategies) {
    #Loop over all PSA iterations
    for (i_iteration in 1:n_iterations) {
      #Loop over all cycles
      for (i_cycle in 2:n_cycles) {
        cohort_vectors[i_cycle, i_monitoring, i_iteration, ] <- 
          cohort_vectors[i_cycle - 1, i_monitoring, i_iteration, ]%*%
          transition_matrices[i_cycle - 1, i_monitoring, i_iteration, , ]
        
        HCC_cohort_vectors[i_cycle-1,i_monitoring,i_iteration,]<-(cohort_vectors[i_cycle,i_monitoring,i_iteration,]+cohort_vectors[i_cycle-1,i_monitoring,i_iteration,])/2
      } #Ends loop over cycles from second cycle
      HCC_cohort_vectors[i_cycle,i_monitoring,i_iteration,]<-cohort_vectors[i_cycle,i_monitoring,i_iteration,]

      #Cycle costs and QALYs
      if(half_cycle_correction==1){
        cycle_costs[, i_monitoring, i_iteration] <- 
          HCC_cohort_vectors[, i_monitoring, i_iteration, ] %*% state_costs[i_monitoring, i_iteration, ]
        for(i_cycle in 1:n_cycles){
          cycle_costs[i_cycle,i_monitoring,i_iteration]<-cycle_costs[i_cycle,i_monitoring,i_iteration]+
            HCC_cohort_vectors[i_cycle, i_monitoring,i_iteration,] %*% intense_monitoring_costs[i_cycle,i_monitoring,i_iteration,]   
        }
                
        if(trial_utilities_switch==1){
          cycle_QALYs[, i_monitoring, i_iteration] <-
            rowSums(HCC_cohort_vectors[, i_monitoring, i_iteration, ] * trial_utilities[,i_monitoring,i_iteration,])
        }else{
          cycle_QALYs[, i_monitoring, i_iteration] <- 
            HCC_cohort_vectors[, i_monitoring, i_iteration, ] %*% t(state_QALYs[i_iteration, ])
        }#Ends trial utilities if
        cycle_LYs[, i_monitoring, i_iteration] <- (1-HCC_cohort_vectors[, i_monitoring, i_iteration,"Death"])/12  
        
      }else{
        cycle_costs[, i_monitoring, i_iteration] <- 
          cohort_vectors[, i_monitoring, i_iteration, ] %*% state_costs[i_monitoring, i_iteration, ]
        
        if(trial_utilities_switch==1){
          cycle_QALYs[, i_monitoring, i_iteration] <-
            rowSums(cohort_vectors[, i_monitoring, i_iteration, ] * trial_utilities[,i_monitoring,i_iteration,])
        }else{
          cycle_QALYs[, i_monitoring, i_iteration] <- 
            cohort_vectors[, i_monitoring, i_iteration, ] %*% t(state_QALYs[i_iteration, ])
        }#Ends trial utilities if
        cycle_LYs[, i_monitoring, i_iteration] <- (1-cohort_vectors[, i_monitoring, i_iteration,"Death"])/12
      }#Ends the half cycle correction if

      
      #Total costs and QALYs
      total_costs[i_monitoring, i_iteration] <- cycle_costs[, i_monitoring, i_iteration] %*% 
        discount_factor+monitoring_costs[i_monitoring, i_iteration]  
        
      total_QALYs[i_monitoring, i_iteration] <- cycle_QALYs[, i_monitoring, i_iteration]%*%
        discount_factor
      total_LYs[i_monitoring, i_iteration] <- cycle_LYs[, i_monitoring, i_iteration]%*%
        discount_factor
      } #Ends loop over iterations
      
    } #Ends loop over monitoring strategies
  
  #Check for HFH rate
  hospitalised<-HCC_cohort_vectors[,"No_monitoring",1,"1st_Hospitalisation"]+HCC_cohort_vectors[,"No_monitoring",1,"2nd_Hospitalisation"]+HCC_cohort_vectors[,"No_monitoring",1,"Subsequent_hospitalisation"]
  alive<-1-HCC_cohort_vectors[,"No_monitoring",1,"Death"]
  stable<-cohort_vectors[,"No_monitoring",1,"Stable_HF"]+cohort_vectors[,"No_monitoring",1,"Stable_HF2"]+cohort_vectors[,"No_monitoring",1,"Stable_HF3"]+cohort_vectors[,"No_monitoring",1,"Stable_HF4"]
  prop_hospitalised<-hospitalised/alive
  #print(prop_hospitalised)
  rate_hospitalised<- -log(1-prop_hospitalised)/cycle_length
  print(rate_hospitalised)
  r_hospitalised_df<-as.data.frame(rate_hospitalised)
  write.csv(r_hospitalised_df, "Rate_hospitalised.csv")
  print(alive)
  
  
  return(list("cycle_costs" = cycle_costs,
              "cycle_QALYs" = cycle_QALYs,
              "total_costs" = total_costs,
              "total_QALYs" = total_QALYs,
              "total_LYs" = total_LYs
              #"ICER" = ICER
              ))
         
  } #Ends the function