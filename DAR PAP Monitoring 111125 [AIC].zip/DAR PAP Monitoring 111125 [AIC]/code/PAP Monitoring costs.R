#PAP Monitoring costs


generate_state_costs <- function(input_parameters) {
  
  #Define an array to store state costs for each treatment, iteration and state
  state_costs <- array(NA, dim = c(n_monitoring_strategies, n_iterations, n_states),
                       dimnames = list(monitoring_names, NULL, state_names))

  #Costs for hospitalised states
  state_costs[, , "Stable_HF"] <-
    matrix(rep(input_parameters$state_costs_Stable_HF, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "Stable_HF2"] <-
    matrix(rep(input_parameters$state_costs_Stable_HF2, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "Stable_HF3"] <-
    matrix(rep(input_parameters$state_costs_Stable_HF3, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "Stable_HF4"] <-
    matrix(rep(input_parameters$state_costs_Stable_HF4, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "1st_Hospitalisation"] <-
    matrix(rep(input_parameters$state_costs_1st_Hospitalisation, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "2nd_Hospitalisation"] <-
    matrix(rep(input_parameters$state_costs_2nd_Hospitalisation, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "Subsequent_hospitalisation"] <-
    matrix(rep(input_parameters$state_costs_Subsequent_hospitalisation, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  state_costs[, , "End_of_life"] <-
    matrix(rep(input_parameters$state_costs_End_of_life, n_monitoring_strategies),
           nrow = n_monitoring_strategies, byrow = T)
  
  
  #Add monthly monitoring costs (low intensity monitoring)
  state_costs["CardioMEMS",,] <- state_costs["CardioMEMS",,] +
    matrix(rep(input_parameters$costs_monthly_monitoring_CM, n_states), ncol = n_states)
  state_costs["Cordella",,] <- state_costs["Cordella",,] +
    matrix(rep(input_parameters$costs_monthly_monitoring_Cordella, n_states), ncol = n_states)
  
  #Add hospitalisation based monitoring
  if(hosp_based_monitoring==1){
    state_costs["CardioMEMS",,"1st_Hospitalisation"]<-state_costs["CardioMEMS",,"1st_Hospitalisation"]+
      input_parameters$costs_intense_monitoring_CM
    state_costs["CardioMEMS",,"2nd_Hospitalisation"]<-state_costs["CardioMEMS",,"2nd_Hospitalisation"]+
      input_parameters$costs_intense_monitoring_CM
    state_costs["CardioMEMS",,"Subsequent_hospitalisation"]<-state_costs["CardioMEMS",,"Subsequent_hospitalisation"]+
      input_parameters$costs_intense_monitoring_CM
    state_costs["Cordella",,"1st_Hospitalisation"]<-state_costs["Cordella",,"1st_Hospitalisation"]+
      input_parameters$costs_intense_monitoring_Cordella
    state_costs["Cordella",,"2nd_Hospitalisation"]<-state_costs["Cordella",,"2nd_Hospitalisation"]+
      input_parameters$costs_intense_monitoring_Cordella
    state_costs["Cordella",,"Subsequent_hospitalisation"]<-state_costs["Cordella",,"Subsequent_hospitalisation"]+
      input_parameters$costs_intense_monitoring_Cordella
  }
  
  
  # Zero cost of being in the dead state
  state_costs[, , "Death"] <- 0
  
  return(state_costs)
  
}