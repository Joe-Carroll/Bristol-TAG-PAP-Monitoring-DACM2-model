#Trial based utilities

generate_trial_utilities <- function(input_parameters) {
  
  #Define an array to store utilites for each treatment, iteration and state
  trial_utilities <- array(NA, dim = c(n_cycles,n_monitoring_strategies, n_iterations, n_states),
                       dimnames = list(NULL, monitoring_names, NULL, state_names))
 
  #Scenario 6c
  if(scenario_6c == 1){
    #Populate first year with trial utilities
    trial_utilities[1:3,1:2,,]<-input_parameters$tutil_treatment_1m
    trial_utilities[4:6,1:2,,]<-input_parameters$tutil_treatment_3m
    trial_utilities[7:12,1:2,,]<-input_parameters$tutil_treatment_6m
    trial_utilities[1:3,3,,]<-input_parameters$tutil_usual_care_1m
    trial_utilities[4:6,3,,]<-input_parameters$tutil_usual_care_3m
    trial_utilities[7:12,3,,]<-input_parameters$tutil_usual_care_6m
    
    #After 12 months
    trial_utilities[13:n_cycles,,,"Stable_HF"]<-input_parameters$utilities_Stable_HF
    trial_utilities[13:n_cycles,,,"1st_Hospitalisation"]<-input_parameters$utilities_1st_Hospitalisation
    trial_utilities[13:n_cycles,,,"Stable_HF2"]<-input_parameters$utilities_Stable_HF2
    trial_utilities[13:n_cycles,,,"2nd_Hospitalisation"]<-input_parameters$utilities_2nd_Hospitalisation
    trial_utilities[13:n_cycles,,,"Stable_HF3"]<-input_parameters$utilities_Stable_HF3
    trial_utilities[13:n_cycles,,,"Subsequent_hospitalisation"]<-input_parameters$utilities_Subsequent_hospitalisation
    trial_utilities[13:n_cycles,,,"Stable_HF4"]<-input_parameters$utilities_Stable_HF4
    trial_utilities[13:n_cycles,,,"End_of_life"]<-input_parameters$utilities_End_of_life
    
    #Death state
    trial_utilities[,,, "Death"] <- 0
    
    
  }else{ 
  
    #Populate the array - Intervention
    trial_utilities[1:3,1:2,,]<-input_parameters$tutil_treatment_1m
    trial_utilities[4:6,1:2,,]<-input_parameters$tutil_treatment_3m
    trial_utilities[7:12,1:2,,]<-input_parameters$tutil_treatment_6m
    trial_utilities[13:24,1:2,,]<-input_parameters$tutil_treatment_12m
    trial_utilities[25:60,1:2,,]<-input_parameters$tutil_treatment_12m
   
    
    #Populate the array - Usual care
    trial_utilities[1:3,3,,]<-input_parameters$tutil_usual_care_1m
    trial_utilities[4:6,3,,]<-input_parameters$tutil_usual_care_3m
    trial_utilities[7:12,3,,]<-input_parameters$tutil_usual_care_6m
    trial_utilities[13:24,3,,]<-input_parameters$tutil_usual_care_12m
    trial_utilities[25:60,3,,]<-input_parameters$tutil_usual_care_12m
    
     #Code for utilities to merge after 5 years
    trial_utilities[61:n_cycles,,,]<-input_parameters$tutil_5y
    
    #Annual decline
    for (i_cycle in 1:60) {
      trial_utilities[i_cycle,,,]<-trial_utilities[i_cycle,,,]-floor(((i_cycle-13)/12))*input_parameters$tutil_annual_decline
    }
    for (i_cycle in 61:n_cycles) {
      trial_utilities[i_cycle,,,]<-trial_utilities[i_cycle,,,]-floor(((i_cycle-61)/12))*input_parameters$tutil_annual_decline
    }
    #Death state
    
    trial_utilities[,,, "Death"] <- 0
  }#End scenario 6c if
  #row<-trial_utilities[13,,1,]
  #print(row)
  return(trial_utilities)
  
}