#PAP monitoring reading inputs

require(readxl)

generate_input_parameters <- function(n_iterations) {
  input_parameters <- as.data.frame(matrix(nrow = n_iterations, ncol = 83))
  colnames(input_parameters) <- c("HF_hospitalisation",
                                  "LHR_hospitalisation_for_HF2",
                                  "LHR_hospitalisation_for_HF3",
                                  "LHR_hospitalisation_for_HF4",
                                  "LHR_CM_hosp",
                                  "LHR_Cordella_hosp",
                                  "LHR_CM_mort",
                                  "LHR_Cordella_mort",
                                  paste0("log_rate_1st_hospitalisation_", monitoring_names),
                                  paste0("log_rate_2nd_hospitalisation_", monitoring_names),
                                  paste0("log_rate_3rd_hospitalisation_", monitoring_names),
                                  paste0("log_rate_4th_hospitalisation_", monitoring_names),
                                  "implant_failure_CM",
                                  "implant_failure_Cordella",
                                  "device_complication_CM",
                                  "device_complication_Cordella",
                                  paste0("mortality_", monitoring_names),
                                  paste0("mortality_", mortality_groups),
                                  "LHR_mortality_SHF2",
                                  "LHR_mortality_SHF3",
                                  "LHR_mortality_SHF4",
                                  paste0("state_costs_", state_names),
                                  paste0("monitoring_costs_", monitoring_names),
                                  "costs_device_CM",
                                  "costs_device_Cordella",
                                  "costs_implantation_CM",
                                  "costs_implantation_Cordella",
                                  "costs_device_failure_CM",
                                  "costs_device_failure_Cordella",
                                  "costs_implant_failure_CM",
                                  "costs_implant_failure_Cordella",
                                  "costs_monthly_monitoring_CM",
                                  "costs_monthly_monitoring_Cordella",
                                  "costs_intense_monitoring_CM",
                                  "costs_intense_monitoring_Cordella",
                                  paste0("utilities_", state_names),
                                  "tutil_treatment_1m",
                                  "tutil_treatment_3m",
                                  "tutil_treatment_6m",
                                  "tutil_treatment_12m",
                                  "tutil_5y",
                                  "tutil_usual_care_1m",
                                  "tutil_usual_care_3m",
                                  "tutil_usual_care_6m",
                                  "tutil_usual_care_12m",
                                  "tutil_annual_decline"
  )


#Import data
  if(scenario_file_used==1){
    file_name<-scenario_file
  }else{
    if(HTW_model==1){
      file_name<-"/HTW inputs sheet.xlsx"
    }else{
      if(deterministic_file_used==1){
        file_name<-"/Model inputs sheet Deterministic.xlsx"
      }else{
        file_name <-"/Model inputs sheet.xlsx"
      }
    }
  }
  #Transition probabilities
  rates_raw <- read_excel(paste0(data_directory, file_name), sheet = "Transition probabilities")
  #Costs
  costs_raw <- read_excel(paste0(data_directory, file_name), sheet = "Costs")
  #Utilities
  utilities_raw <- read_excel(paste0(data_directory, file_name), sheet = "Utilities")
  utilities_tr_raw <- read_excel(paste0(data_directory, file_name), sheet = "Trial utilities")
#Setting distributions                                                                    
  input_parameters$HF_hospitalisation <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "log_rate_HF_hospitalisation"],
                                                                  sd = SE[variable == "log_rate_HF_hospitalisation"]))

  input_parameters$LHR_hospitalisation_for_HF2 <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_hospitalisation_for_HF2"],
                                                                          sd = SE[variable == "LHR_hospitalisation_for_HF2"]))
    
  input_parameters$LHR_hospitalisation_for_HF3 <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_hospitalisation_for_HF3"],
                                                                          sd = SE[variable == "LHR_hospitalisation_for_HF3"]))
    
  input_parameters$LHR_hospitalisation_for_HF4 <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_hospitalisation_for_HF4"],
                                                                          sd = SE[variable == "LHR_hospitalisation_for_HF4"]))
    
  input_parameters$LHR_CM_hosp <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_CM_hosp"],
                                                       sd = SE[variable == "LHR_CM_hosp"]))

  input_parameters$LHR_Cordella_hosp <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_Cordella_hosp"],
                                                                sd = SE[variable == "LHR_Cordella_hosp"]))

  input_parameters$LHR_CM_mort <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_CM_mort"],
                                                          sd = SE[variable == "LHR_CM_mort"]))
    
  input_parameters$LHR_Cordella_mort <-with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_Cordella_mort"],
                                                               sd = SE[variable == "LHR_Cordella_mort"]))

  #Transition rates
  if(HTW_model==1){
    input_parameters$log_rate_1st_hospitalisation_CardioMEMS <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "1st_hospitalisation_CM"],
                                                                                          sd = SE[variable == "1st_hospitalisation_CM"]))
    input_parameters$log_rate_1st_hospitalisation_Cordella <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "1st_hospitalisation_Cordella"],
                                                                                          sd = SE[variable == "1st_hospitalisation_Cordella"]))
    input_parameters$log_rate_1st_hospitalisation_No_monitoring <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "1st_hospitalisation_NM"],
                                                                                          sd = SE[variable == "1st_hospitalisation_NM"]))
    input_parameters$log_rate_2nd_hospitalisation_CardioMEMS <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "2nd_hospitalisation_CM"],
                                                                                          sd = SE[variable == "2nd_hospitalisation_CM"]))
    input_parameters$log_rate_2nd_hospitalisation_Cordella <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "2nd_hospitalisation_Cordella"],
                                                                                        sd = SE[variable == "2nd_hospitalisation_Cordella"]))
    input_parameters$log_rate_2nd_hospitalisation_No_monitoring <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "2nd_hospitalisation_NM"],
                                                                                          sd = SE[variable == "2nd_hospitalisation_NM"]))
    input_parameters$log_rate_3rd_hospitalisation_CardioMEMS <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "3rd_hospitalisation_CM"],
                                                                                          sd = SE[variable == "3rd_hospitalisation_CM"]))
    input_parameters$log_rate_3rd_hospitalisation_Cordella <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "3rd_hospitalisation_Cordella"],
                                                                                          sd = SE[variable == "3rd_hospitalisation_Cordella"]))
    input_parameters$log_rate_3rd_hospitalisation_No_monitoring <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "3rd_hospitalisation_NM"],
                                                                                          sd = SE[variable == "3rd_hospitalisation_NM"]))
    input_parameters$log_rate_4th_hospitalisation_CardioMEMS <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "4th_hospitalisation_CM"],
                                                                                      sd = SE[variable == "4th_hospitalisation_CM"]))
    input_parameters$log_rate_4th_hospitalisation_Cordella <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "4th_hospitalisation_Cordella"],
                                                                                    sd = SE[variable == "4th_hospitalisation_Cordella"]))
    input_parameters$log_rate_4th_hospitalisation_No_monitoring <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "4th_hospitalisation_NM"],
                                                                          sd = SE[variable == "4th_hospitalisation_NM"]))
    input_parameters$implant_failure_CM <- 0
      
    input_parameters$implant_failure_Cordella <- 0
      
    input_parameters$device_complication_CM <- 0
      
    input_parameters$device_complication_Cordella <- 0                                                                                                                                                                          

  }else{
    #Creates monthly log hazard rates for each monitoring strategy and each hospitalisation
    input_parameters$log_rate_1st_hospitalisation_CardioMEMS <- input_parameters$HF_hospitalisation + input_parameters$LHR_CM_hosp - log(1/cycle_length)
    input_parameters$log_rate_1st_hospitalisation_Cordella <- input_parameters$HF_hospitalisation + input_parameters$LHR_Cordella_hosp - log(1/cycle_length)
    input_parameters$log_rate_1st_hospitalisation_No_monitoring <-input_parameters$HF_hospitalisation - log(1/cycle_length)
    input_parameters$log_rate_2nd_hospitalisation_CardioMEMS <- input_parameters$HF_hospitalisation + input_parameters$LHR_CM_hosp + input_parameters$LHR_hospitalisation_for_HF2 - log(1/cycle_length)
    input_parameters$log_rate_2nd_hospitalisation_Cordella <- input_parameters$HF_hospitalisation + input_parameters$LHR_Cordella_hosp + input_parameters$LHR_hospitalisation_for_HF2 - log(1/cycle_length)
    input_parameters$log_rate_2nd_hospitalisation_No_monitoring <- input_parameters$HF_hospitalisation + input_parameters$LHR_hospitalisation_for_HF2 - log(1/cycle_length)
    input_parameters$log_rate_3rd_hospitalisation_CardioMEMS <- input_parameters$HF_hospitalisation + input_parameters$LHR_CM_hosp + input_parameters$LHR_hospitalisation_for_HF3 - log(1/cycle_length)
    input_parameters$log_rate_3rd_hospitalisation_Cordella <- input_parameters$HF_hospitalisation + input_parameters$LHR_Cordella_hosp + input_parameters$LHR_hospitalisation_for_HF3 - log(1/cycle_length)
    input_parameters$log_rate_3rd_hospitalisation_No_monitoring <- input_parameters$HF_hospitalisation + input_parameters$LHR_hospitalisation_for_HF3  - log(1/cycle_length)
    input_parameters$log_rate_4th_hospitalisation_CardioMEMS <- input_parameters$HF_hospitalisation + input_parameters$LHR_CM_hosp + input_parameters$LHR_hospitalisation_for_HF4 - log(1/cycle_length)
    input_parameters$log_rate_4th_hospitalisation_Cordella <- input_parameters$HF_hospitalisation + input_parameters$LHR_Cordella_hosp + input_parameters$LHR_hospitalisation_for_HF4 - log(1/cycle_length)
    input_parameters$log_rate_4th_hospitalisation_No_monitoring <- input_parameters$HF_hospitalisation + input_parameters$LHR_hospitalisation_for_HF4  - log(1/cycle_length)
  
    #Device rates
    input_parameters$implant_failure_CM <- expit(with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "log_rate_implant_failure_CM"],sd = SE[variable == "log_rate_implant_failure_CM"])))
    
    input_parameters$implant_failure_Cordella <- expit(with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "log_rate_implant_failure_Cordella"],sd = SE[variable == "log_rate_implant_failure_Cordella"])))
    
    input_parameters$device_complication_CM <- expit(with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "log_rate_device_complication_CM"],sd = SE[variable == "log_rate_device_complication_CM"])))
    
    input_parameters$device_complication_Cordella <- expit(with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "log_rate_device_complication_Cordella"],sd = SE[variable == "log_rate_device_complication_Cordella"])))
  }
  #Mortalities
  input_parameters$mortality_CardioMEMS <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_CM"],
                                                                                        sd = SE[variable == "mortality_CM"]))
  input_parameters$mortality_Cordella <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_Cordella"],
                                                                                      sd = SE[variable == "mortality_Cordella"]))
  input_parameters$mortality_No_monitoring <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_NM"],
                                                                                        sd = SE[variable == "mortality_NM"]))
  input_parameters$mortality_45_50 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_45_50"],
                                                                        sd = SE[variable == "mortality_45_50"]))
  input_parameters$mortality_50_55 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_50_55"],
                                                                        sd = SE[variable == "mortality_55_60"]))
  input_parameters$mortality_55_60 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_55_60"],
                                                                        sd = SE[variable == "mortality_55_60"]))
  input_parameters$mortality_60_65 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_60_65"],
                                                                        sd = SE[variable == "mortality_60_65"]))
  input_parameters$mortality_65_70 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_65_70"],
                                                                sd = SE[variable == "mortality_65_70"]))
  input_parameters$mortality_70_75 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_70_75"],
                                                                sd = SE[variable == "mortality_70_75"]))
  input_parameters$mortality_75_80 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_75_80"],
                                                                sd = SE[variable == "mortality_75_80"]))
  input_parameters$mortality_80_85 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_80_85"],
                                                                sd = SE[variable == "mortality_80_85"]))
  input_parameters$mortality_85_90 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_85_90"],
                                                                sd = SE[variable == "mortality_85_90"]))
  input_parameters$mortality_90 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "mortality_90"],
                                                                sd = SE[variable == "mortality_90"]))
  #Mortality LHRs
  input_parameters$LHR_mortality_SHF2 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_mortality_SHF2"],
                                                             sd = SE[variable == "LHR_mortality_SHF2"]))
  input_parameters$LHR_mortality_SHF3 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_mortality_SHF3"],
                                                             sd = SE[variable == "LHR_mortality_SHF3"]))
  input_parameters$LHR_mortality_SHF4 <- with(rates_raw, rnorm(n_iterations, mean = Mean[variable == "LHR_mortality_SHF4"],
                                                             sd = SE[variable == "LHR_mortality_SHF4"]))
  
  #Health state costs
  
  input_parameters$state_costs_Stable_HF<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "stable_HF"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "stable_HF"],rate = 1))} 
  input_parameters$state_costs_1st_Hospitalisation<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "1st_hospitalisation"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "1st_hospitalisation"],rate = 1))} 
  input_parameters$state_costs_Stable_HF2<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "stable_HF2"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "stable_HF2"],rate = 1))} 
  input_parameters$state_costs_2nd_Hospitalisation<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "2nd_hospitalisation"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "2nd_hospitalisation"],rate = 1))} 
  input_parameters$state_costs_Stable_HF3<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "stable_HF3"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "stable_HF3"],rate = 1))} 
  input_parameters$state_costs_Subsequent_hospitalisation<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "subsequent_hospitalisation"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "subsequent_hospitalisation"],rate = 1))} 
  input_parameters$state_costs_Stable_HF4<- if(deterministic_analysis==1){
    rep(with(costs_raw, Mean[Cost == "stable_HF4"]), n_iterations)
  }else{
    with(costs_raw, rgamma(n_iterations, shape = Mean[Cost == "stable_HF4"],rate = 1))} 
  input_parameters$state_costs_End_of_life<- 0
  #with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "end_of_life_care"],
                                            #sd = SE[Cost == "end_of_life_care"]))
  input_parameters$state_costs_Death<-0
  
  
  #Monitoring costs (variable)
  input_parameters$costs_implantation_CM <- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "implantation_CM"],
                                                             sd = SE[Cost == "implantation_CM"]))
  input_parameters$costs_implantation_Cordella <- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "implantation_Cordella"],
                                                                 sd = SE[Cost == "implantation_Cordella"]))
  input_parameters$costs_device_failure_CM <- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "device_failure_CM"],
                                                             sd = SE[Cost == "device_failure_CM"]))
  input_parameters$costs_device_failure_Cordella <- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "device_failure_Cordella"],
                                                                   sd = SE[Cost == "device_failure_Cordella"]))
  input_parameters$costs_implant_failure_CM <- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "implant_failure_CM"],
                                                              sd = SE[Cost == "implant_failure_CM"]))
  input_parameters$costs_implant_failure_Cordella <- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "implant_failure_Cordella"],
                                                                    sd = SE[Cost == "implant_failure_Cordella"]))
    
  #Monitoring costs(duplicate for both monitoring)
  input_parameters$costs_monthly_monitoring_CM<- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "monthly_monitoring_CM"],
                                                                  sd = SE[Cost == "monthly_monitoring_CM"]))
  input_parameters$costs_monthly_monitoring_Cordella<- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "monthly_monitoring_Cordella"],
                                                                       sd = SE[Cost == "monthly_monitoring_Cordella"]))
  input_parameters$costs_intense_monitoring_CM<- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "intense_monitoring_CM"],
                                                                       sd = SE[Cost == "intense_monitoring_CM"]))
  input_parameters$costs_intense_monitoring_Cordella<- with(costs_raw, rnorm(n_iterations, mean = Mean[Cost == "intense_monitoring_Cordella"],
                                                                             sd = SE[Cost == "intense_monitoring_Cordella"]))
  #Monitoring costs(fixed)
  if(threshold_analysis_switch==1){
       input_parameters$costs_device_CM <- rep(active_threshold_price, n_iterations)
    input_parameters$costs_device_Cordella <- rep(active_threshold_price, n_iterations)
    
  }else{
    input_parameters$costs_device_CM <- rep(with(costs_raw, Mean[Cost == "device_CM"]), n_iterations)
    input_parameters$costs_device_Cordella <- rep(with(costs_raw, Mean[Cost == "device_Cordella"]), n_iterations)
  }
 
   #Monitoring costs for HTW scenario
  input_parameters$monitoring_costs_CardioMEMS <- rep(with(costs_raw, Mean[Cost == "cardioMEMS"]), n_iterations)
  input_parameters$monitoring_costs_Cordella <- rep(with(costs_raw, Mean[Cost == "cordella"]), n_iterations)
  input_parameters$monitoring_costs_No_monitoring <- rep(with(costs_raw, Mean[Cost == "no_monitoring"]), n_iterations)

  #Utilities
  input_parameters$utilities_Stable_HF <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "stable_HF1"],
                                                                     sd = SE[State == "stable_HF1"]))
  input_parameters$utilities_1st_Hospitalisation <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "1st_hospitalisation"],
                                                                     sd = SE[State == "1st_hospitalisation"]))
  input_parameters$utilities_Stable_HF2 <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "stable_HF2"],
                                                                     sd = SE[State == "stable_HF2"]))
  input_parameters$utilities_2nd_Hospitalisation <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "2nd_hospitalisation"],
                                                                     sd = SE[State == "2nd_hospitalisation"]))
  input_parameters$utilities_Stable_HF3 <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "stable_HF3"],
                                                                     sd = SE[State == "stable_HF3"]))
  input_parameters$utilities_Subsequent_hospitalisation <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "subsequent_hospitalisation"],
                                                                     sd = SE[State == "subsequent_hospitalisation"]))
  input_parameters$utilities_Stable_HF4 <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "stable_HF4"],
                                                                     sd = SE[State == "stable_HF4"]))
  input_parameters$utilities_End_of_life <- with(utilities_raw, rnorm(n_iterations, mean = Mean[State == "end_of_life_care"],
                                                                     sd = SE[State == "end_of_life_care"]))
  #Utility in the death state
  input_parameters$utilities_Death <- 0
  
  #Trial based utilities
  input_parameters$tutil_treatment_1m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "1m_treatment_group"],
                                                                         sd = SE[Utility == "1m_treatment_group"]))
  input_parameters$tutil_treatment_3m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "3m_treatment_group"],
                                                                         sd = SE[Utility == "3m_treatment_group"]))
  input_parameters$tutil_treatment_6m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "6m_treatment_group"],
                                                                         sd = SE[Utility == "6m_treatment_group"]))
  input_parameters$tutil_treatment_12m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "12m_treatment_group"],
                                                                         sd = SE[Utility == "12m_treatment_group"]))
  input_parameters$tutil_5y <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "5y"],
                                                                          sd = SE[Utility == "5y"]))
  input_parameters$tutil_usual_care_1m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "1m_usual_care"],
                                                                         sd = SE[Utility == "1m_usual_care"]))
  input_parameters$tutil_usual_care_3m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "3m_usual_care"],
                                                                         sd = SE[Utility == "3m_usual_care"]))
  input_parameters$tutil_usual_care_6m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "6m_usual_care"],
                                                                         sd = SE[Utility == "6m_usual_care"]))
  input_parameters$tutil_usual_care_12m <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "12m_usual_care"],
                                                                         sd = SE[Utility == "12m_usual_care"]))
  input_parameters$tutil_annual_decline <-with(utilities_tr_raw, rnorm(n_iterations, mean = Mean[Utility == "annual_utility_decline"],
                                                                           sd = SE[Utility == "annual_utility_decline"]))
  
  
  return(input_parameters)
}