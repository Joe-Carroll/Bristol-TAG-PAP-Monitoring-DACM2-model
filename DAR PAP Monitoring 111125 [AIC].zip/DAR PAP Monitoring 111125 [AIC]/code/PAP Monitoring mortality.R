#Set up the age based mortality mechanism

generate_mortality_rates <- function(input_parameters){
  
  mortality_matrix <- array(NA, dim = c(n_cycles,n_monitoring_strategies, n_iterations, n_states),
                            dimnames = list(NULL,monitoring_names, NULL, state_names))
  if(HTW_model==1){
    mortality_matrix[,"CardioMEMS",,]<-  (1 - exp(-exp(input_parameters$mortality_CardioMEMS)))
    mortality_matrix[,"Cordella",,]<-  (1 - exp(-exp(input_parameters$mortality_Cordella)))
    mortality_matrix[,"No_monitoring",,]<-  (1 - exp(-exp(input_parameters$mortality_No_monitoring)))
  }else{
  
    for(i_iteration in 1:n_iterations){
      for (i_cycle in 1:n_cycles) {
        mortality_counter<-initial_age
        mortality_counter<-mortality_counter-1/12+i_cycle/12
        if(mortality_counter<=50){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_45_50[i_iteration]
        }else if(mortality_counter>50 & mortality_counter<=55){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_50_55[i_iteration]
        }else if(mortality_counter>55 & mortality_counter<=60){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_55_60[i_iteration]
        }else if(mortality_counter>60 & mortality_counter<=65){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_60_65[i_iteration]
        }else if(mortality_counter>65 & mortality_counter<=70){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_65_70[i_iteration]
        }else if(mortality_counter>70 & mortality_counter<=75){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_70_75[i_iteration]
        }else if(mortality_counter>75 & mortality_counter<=80){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_75_80[i_iteration]
        }else if(mortality_counter>80 & mortality_counter<=85){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_80_85[i_iteration]  
        }else if(mortality_counter>85 & mortality_counter<=90){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_85_90[i_iteration]
        }else if(mortality_counter>90){
          mortality_matrix[i_cycle,,i_iteration,]<-input_parameters$mortality_90[i_iteration]
        }#End of if
        
      }#End of cycle loop
    }#End of iterations loop
    
    #Set death rate to 1
    mortality_matrix[,,,"Death"]<-1
    
    #Mortality transformations monthly probability -> hazard rates
    mortality_matrix <- log(-log(1-mortality_matrix)/cycle_length)
    
    #Incorporate SHF hazard ratios
    for (i_iteration in 1:n_iterations) {
      mortality_matrix[,,i_iteration,"1st_Hospitalisation"]<-mortality_matrix[,,i_iteration,"1st_Hospitalisation"]+input_parameters$LHR_mortality_SHF2[i_iteration]
      mortality_matrix[,,i_iteration,"Stable_HF2"]<-mortality_matrix[,,i_iteration,"Stable_HF2"]+input_parameters$LHR_mortality_SHF2[i_iteration]
      mortality_matrix[,,i_iteration,"2nd_Hospitalisation"]<-mortality_matrix[,,i_iteration,"2nd_Hospitalisation"]+input_parameters$LHR_mortality_SHF3[i_iteration]
      mortality_matrix[,,i_iteration,"Stable_HF3"]<-mortality_matrix[,,i_iteration,"Stable_HF3"]+input_parameters$LHR_mortality_SHF3[i_iteration]
      mortality_matrix[,,i_iteration,"Subsequent_hospitalisation"]<-mortality_matrix[,,i_iteration,"Subsequent_hospitalisation"]+input_parameters$LHR_mortality_SHF4[i_iteration]
      mortality_matrix[,,i_iteration,"Stable_HF4"]<-mortality_matrix[,,i_iteration,"Stable_HF4"]+input_parameters$LHR_mortality_SHF4[i_iteration]
    }
    #Add in treatment effect
    for (i_iteration in 1:n_iterations) {
      mortality_matrix[,"CardioMEMS",i_iteration,]<-mortality_matrix[,"CardioMEMS",i_iteration,]+input_parameters$LHR_CM_mort[i_iteration]
      mortality_matrix[,"Cordella",i_iteration,]<-mortality_matrix[,"Cordella",i_iteration,]+input_parameters$LHR_Cordella_mort[i_iteration]
    }
    #Transform hazard ratios to probabilities hazard -> model probability
    mortality_matrix<- 1-exp(-exp(mortality_matrix)*cycle_length)
  }#End HTW if
  

  return(mortality_matrix)
}