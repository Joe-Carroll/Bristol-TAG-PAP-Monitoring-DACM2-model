#Scenario analyses
#Create a data frame with the results

library(rje)

n_scenarios<-6
scenario_names<-c("1",
                  "2",
                  "3",
                  "4",
                  "5",
                  "6")
#Scenario results
n_s_results<-6
s_results<-c("Total_costs",
             "Total_QALYs",
             "Total_LYs",
             "Incremental_costs",
             "Incremental_QALYs",
             "ICERs")




##Run the scenario model
#Load file
deterministic_file_used<-1


#Set seed
set.seed(29949510)
#Load libraries

# Define global parameters for the data and source code directories
data_directory <- "data"
code_directory <- "code"

#Load functions
source(paste0(code_directory, "/PAP Monitoring inputs.R"))
source(paste0(code_directory, "/PAP Monitoring transition matrix.R"))
source(paste0(code_directory, "/PAP Monitoring mortality.R"))
source(paste0(code_directory, "/PAP Monitoring costs.R"))
source(paste0(code_directory, "/PAP Monitoring intense monitoring costs.R"))
source(paste0(code_directory, "/PAP Monitoring trial utilities.R"))
source(paste0(code_directory, "/PAP Monitoring calculations.R"))

# Define global parameters that are accessed by all functions
deterministic_analysis<-1
n_iterations<-1
n_states<-9
n_monitoring_strategies<-3
n_cycles<-396
HTW_model<-0
half_cycle_correction<-1
trial_utilities_switch<-1
adherence_drop_off<-0
adherence_rate<-0.95
scenario_6c<-1 #Must turn on trial_utilities_switch
threshold_analysis_switch<-0
hosp_based_monitoring<-0

#Cycle length in yrs
cycle_length<-1/12
#Per cycle discount rate
Discount_rate<-0.035

#Cohort demographics
##Age
#initial_age<-69
##Sex
prop_f<-0.30

#CEP printed
CEP<-"CardioMEMS"

#Health states
state_names<-c("Stable_HF",
               "1st_Hospitalisation",
               "Stable_HF2",
               "2nd_Hospitalisation",
               "Stable_HF3",
               "Subsequent_hospitalisation",
               "Stable_HF4",
               "End_of_life",
               "Death")

#Monitoring strategies
monitoring_names<-c("CardioMEMS",
                    "Cordella",
                    "No_monitoring")

#Mortality age groups
mortality_groups<-c("45_50",
                    "50_55",
                    "55_60",
                    "60_65",
                    "65_70",
                    "70_75",
                    "75_80",
                    "80_85",
                    "85_90",
                    "90")

scenario_results<-array(dim = c( n_s_results, n_monitoring_strategies,n_scenarios), 
                        dimnames = list( s_results,monitoring_names,scenario_names)) 

run_scenario_model <- function() { 
  #Generate a matrix of input parameters
  input_parameters <- generate_input_parameters(n_iterations)
  
  # Generate the ICER using the above input parameters
  model_output <- generate_ICER(input_parameters)
  
  # Average costs
  
  costs<- rowMeans(model_output$total_costs, na.rm = TRUE)
  # Average QALYS
  QALYs<-rowMeans(model_output$total_QALYs)
  # Average LYs
  LYs<-rowMeans(model_output$total_LYs)
  
  # Calculate an ICER without BCEA
  incremental_costs <- t(model_output$total_costs) - t(model_output$total_costs)[, "No_monitoring"]
  incremental_QALYs <- t(model_output$total_QALYs) - t(model_output$total_QALYs)[, "No_monitoring"]
  ICER <- colMeans(incremental_costs) / colMeans(incremental_QALYs)
  
  #Report results
  ICER
  return(list("costs" = costs,
              "QALYs" = QALYs,
              "incremental_costs" = incremental_costs,
              "incremental_QALYs" = incremental_QALYs,
              "LYs" = LYs,
              "ICER" = ICER
  ))
}#End scenario model
scenario_file_used<-0
#run_scenario_model()
initial_age<-69
#1

scenario_file_used=0
run_scenario_model()
model_output<-run_scenario_model()
scenario_results["Total_costs",,"1"]<-model_output$costs
scenario_results["Total_QALYs",,"1"]<-model_output$QALYs
scenario_results["Total_LYs",,"1"]<-model_output$LYs
scenario_results["Incremental_costs",,"1"]<-model_output$incremental_costs
scenario_results["Incremental_QALYs",,"1"]<-model_output$incremental_QALYs
scenario_results["ICERs",,"1"]<-model_output$ICER


#2
scenario_file_used=1
scenario_file<-"/Model inputs sheet Deterministic - MONITOR HF.xlsx"
run_scenario_model()
model_output<-run_scenario_model()
scenario_results["Total_costs",,"2"]<-model_output$costs
scenario_results["Total_QALYs",,"2"]<-model_output$QALYs
scenario_results["Total_LYs",,"2"]<-model_output$LYs
scenario_results["Incremental_costs",,"2"]<-model_output$incremental_costs
scenario_results["Incremental_QALYs",,"2"]<-model_output$incremental_QALYs
scenario_results["ICERs",,"2"]<-model_output$ICER


#3
scenario_file_used=1
scenario_file<-"/Model inputs sheet Deterministic - GUIDE HF.xlsx"
run_scenario_model()
model_output<-run_scenario_model()
scenario_results["Total_costs",,"3"]<-model_output$costs
scenario_results["Total_QALYs",,"3"]<-model_output$QALYs
scenario_results["Total_LYs",,"3"]<-model_output$LYs
scenario_results["Incremental_costs",,"3"]<-model_output$incremental_costs
scenario_results["Incremental_QALYs",,"3"]<-model_output$incremental_QALYs
scenario_results["ICERs",,"3"]<-model_output$ICER

#4
scenario_file_used=1
scenario_file<-"/Model inputs sheet company's monitoring schedule.xlsx"
run_scenario_model()
model_output<-run_scenario_model()
scenario_results["Total_costs",,"4"]<-model_output$costs
scenario_results["Total_QALYs",,"4"]<-model_output$QALYs
scenario_results["Total_LYs",,"4"]<-model_output$LYs
scenario_results["Incremental_costs",,"4"]<-model_output$incremental_costs
scenario_results["Incremental_QALYs",,"4"]<-model_output$incremental_QALYs
scenario_results["ICERs",,"4"]<-model_output$ICER

#5
scenario_file_used=1
scenario_file<-"/Model inputs sheet - Hosp-based schedule.xlsx"
hosp_based_monitoring<-1
run_scenario_model()
model_output<-run_scenario_model()
scenario_results["Total_costs",,"5"]<-model_output$costs
scenario_results["Total_QALYs",,"5"]<-model_output$QALYs
scenario_results["Total_LYs",,"5"]<-model_output$LYs
scenario_results["Incremental_costs",,"5"]<-model_output$incremental_costs
scenario_results["Incremental_QALYs",,"5"]<-model_output$incremental_QALYs
scenario_results["ICERs",,"5"]<-model_output$ICER
hosp_based_monitoring<-0

#6
scenario_file_used=1
scenario_file<-"/Model inputs sheet Deterministic - Unadjusted HFH rate.xlsx"
run_scenario_model()
model_output<-run_scenario_model()
scenario_results["Total_costs",,"6"]<-model_output$costs
scenario_results["Total_QALYs",,"6"]<-model_output$QALYs
scenario_results["Total_LYs",,"6"]<-model_output$LYs
scenario_results["Incremental_costs",,"6"]<-model_output$incremental_costs
scenario_results["Incremental_QALYs",,"6"]<-model_output$incremental_QALYs
scenario_results["ICERs",,"6"]<-model_output$ICER



## Turn the matrix into a data frame and export the results
scenario_results_df<-as.data.frame(scenario_results)
write.csv(scenario_results_df, "scenario_results.csv")