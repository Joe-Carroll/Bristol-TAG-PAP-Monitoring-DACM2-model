#Creating the transition matrix

generate_transition_matrices <- function(input_parameters) {
#Create the transition matrix
 transition_matrices <- array(0, dim = c(n_cycles, n_monitoring_strategies, n_iterations, n_states, n_states),
                              dimnames = list(NULL,monitoring_names,NULL,state_names,state_names))
 
#Import the life tables
 life_tables <- read_excel(paste0(data_directory, "/Model inputs sheet.xlsx"), sheet = "Life tables")
 
 # Loop over monitoring strategies
 for(monitoring_name in monitoring_names) {
   #Populate transitions to death with the mortality matrix
   mortality_matrix <- generate_mortality_rates(input_parameters)
   
   transition_matrices[,monitoring_name,, "Stable_HF","Death"] <-mortality_matrix[,monitoring_name,,"Stable_HF"]
   transition_matrices[,monitoring_name,, "1st_Hospitalisation", "Death"] <-mortality_matrix[,monitoring_name,,"1st_Hospitalisation"]
   transition_matrices[,monitoring_name,, "Stable_HF2", "Death"] <-mortality_matrix[,monitoring_name,,"Stable_HF2"]
   transition_matrices[,monitoring_name,, "2nd_Hospitalisation", "Death"] <-mortality_matrix[,monitoring_name,,"2nd_Hospitalisation"]
   transition_matrices[,monitoring_name,, "Stable_HF3", "Death"] <-mortality_matrix[,monitoring_name,,"Stable_HF3"]
   transition_matrices[,monitoring_name,, "Subsequent_hospitalisation", "Death"] <-mortality_matrix[,monitoring_name,,"Subsequent_hospitalisation"]
   transition_matrices[,monitoring_name,, "Stable_HF4", "Death"] <- mortality_matrix[,monitoring_name,,"Stable_HF4"]
   
   
   # Main transitions of interest between states
   transition_matrices[, monitoring_name, , "Stable_HF", "1st_Hospitalisation"] <- 
     matrix(rep(
       (1 - exp(-exp(input_parameters[, paste0("log_rate_1st_hospitalisation_", monitoring_name)]))),
       n_cycles), nrow = n_cycles, byrow = T)
   transition_matrices[, monitoring_name, , "1st_Hospitalisation", "Stable_HF2"] <-
     1 - transition_matrices[, monitoring_name, , "1st_Hospitalisation", "Death"]
   transition_matrices[, monitoring_name, , "Stable_HF2", "2nd_Hospitalisation"] <- 
     matrix(rep(
       (1 - exp(-exp(input_parameters[, paste0("log_rate_2nd_hospitalisation_", monitoring_name)]))),
       n_cycles), nrow = n_cycles, byrow = T)
   transition_matrices[, monitoring_name, , "2nd_Hospitalisation", "Stable_HF3"] <-
     1 - transition_matrices[, monitoring_name, , "2nd_Hospitalisation", "Death"]
   transition_matrices[, monitoring_name, , "Stable_HF3", "Subsequent_hospitalisation"] <-
     matrix(rep(
       (1 - exp(-exp(input_parameters[, paste0("log_rate_3rd_hospitalisation_", monitoring_name)]))),
       n_cycles), nrow = n_cycles, byrow = T)
   transition_matrices[, monitoring_name, , "Subsequent_hospitalisation", "Stable_HF4"] <-
     1 - transition_matrices[, monitoring_name, , "Subsequent_hospitalisation", "Death"]
   transition_matrices[, monitoring_name, , "Stable_HF4", "Subsequent_hospitalisation"]<-
     matrix(rep(
       (1 - exp(-exp(input_parameters[, paste0("log_rate_3rd_hospitalisation_", monitoring_name)]))),
       n_cycles), nrow = n_cycles, byrow = T)
   transition_matrices[, monitoring_name, , "Stable_HF4", "End_of_life"] <- 0
      #  1 - exp(-exp(input_parameters[, paste0("mortality_", monitoring_name)]))
   
 }
# Ensure remaining patients stay in state
 for(i_cycle in 1:n_cycles) {
   for(monitoring_name in monitoring_names){
    if (n_iterations==1){
      for(i_state in 1:length(state_names)) {
        transition_matrices[i_cycle, monitoring_name,1, i_state, i_state] <- 1 -
          sum(transition_matrices[i_cycle, monitoring_name,1, i_state, 1: length(state_names)])
      } #End loop over states
    }else{  
      for(i_state in 1:length(state_names)) {
        transition_matrices[i_cycle, monitoring_name, , i_state, i_state] <- 1 - 
          apply(transition_matrices[i_cycle, monitoring_name, , i_state, -i_state], c(1), sum, na.rm=TRUE)
      } #End loop over states
    }#End if
   } #Ends loop over monitoring strategies
  } #Ends loop over cycles
 
 #Adherence scenario
 for (i_cycle in 1:n_cycles) {
    if(adherence_drop_off==1 && i_cycle>=13){
       transition_matrices[i_cycle,"CardioMEMS",,,]<-adherence_rate*transition_matrices[i_cycle,"CardioMEMS",,,]+
                                                    (1-adherence_rate)*transition_matrices[i_cycle,"No_monitoring",,,]
       transition_matrices[i_cycle,"Cordella",,,]<-adherence_rate*transition_matrices[i_cycle,"Cordella",,,]+
                                                     (1-adherence_rate)*transition_matrices[i_cycle,"No_monitoring",,,]
   
    }#End if
 }#End cycle loop

 return(transition_matrices)
} #End of function